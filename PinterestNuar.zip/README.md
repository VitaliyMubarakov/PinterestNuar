# Pinterest Nuar
![Main](./img/VERY_BIG.png)
### Customizable dark theme for pinterest.com

## Features
- Uses the original color palette.
- Does not invert colors.
- Supports settings menu.

- The User can change: 
    1. Rounding of images
    2. Corners indentation

## Screenshots
![image](https://user-images.githubusercontent.com/58411554/181499145-d95b2059-97d4-48fe-aec9-ea9a69503f5e.png)
