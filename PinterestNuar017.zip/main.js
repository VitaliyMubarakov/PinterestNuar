console.log(newCommand);

if (newCommand == "AddSubButton") AddSubBut();

if (newCommand == "AddSub") ss();

